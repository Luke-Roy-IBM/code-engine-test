# Default Podman Network Configuration with DNS

This configuration enables DNS resolution on Podman's default network, allowing containers to communicate using their names without creating custom networks.

## What This Does

- Enables DNS on the default `podman` network
- Containers can reach each other by name (e.g., `http://web`, `http://db`)
- No need to create or specify custom networks
- No need to expose ports with `-p` for inter-container communication

## Quick Setup

### Automated Setup (Recommended)

```bash
chmod +x setup-default-network.sh
./setup-default-network.sh
```

### Manual Setup

1. **Copy configuration file**:
   ```bash
   mkdir -p ~/.config/containers
   cp default-network-config/containers.conf ~/.config/containers/
   ```

2. **Verify default network exists** (it should already exist):
   ```bash
   podman network ls
   ```

3. **If needed, recreate with DNS enabled**:
   ```bash
   podman network rm podman
   podman network create podman
   ```

4. **Verify DNS is enabled**:
   ```bash
   podman network inspect podman | jq '.[0].dns_enabled'
   ```

## Usage Examples

### Example 1: Web Server and Client

```bash
# Start nginx web server
podman run -d --name web nginx

# Access it from another container using the name 'web'
podman run --rm alpine wget -qO- http://web

# No -p flag needed for internal communication
```

### Example 2: Database and Application

```bash
# Start PostgreSQL database
podman run -d --name db \
    -e POSTGRES_PASSWORD=secret \
    postgres

# Connect from another container using hostname 'db'
podman run --rm postgres psql -h db -U postgres
```

### Example 3: Multi-Container Stack

```bash
# Backend API
podman run -d --name api my-api-image

# Frontend (only this needs -p for external access)
podman run -d --name frontend \
    -e API_URL=http://api:8080 \
    -p 3000:3000 \
    my-frontend-image

# Frontend can reach API at http://api:8080 internally
# External users access frontend at http://localhost:3000
```

### Example 4: Redis and Worker

```bash
# Start Redis
podman run -d --name redis redis

# Start worker that connects to Redis
podman run -d --name worker \
    -e REDIS_HOST=redis \
    my-worker-image

# Worker connects to redis:6379 automatically
```

## How It Works

1. **Default Network**: Podman automatically uses the `podman` network if no network is specified
2. **DNS Resolution**: With netavark backend and DNS enabled, container names are registered in DNS
3. **Name-Based Communication**: Containers resolve each other's names to IP addresses automatically
4. **No Configuration Per Container**: Just use `--name` when running containers

## Configuration Details

### Network Backend: Netavark

Netavark is the modern network backend that provides:
- Built-in DNS server
- Automatic name resolution
- Better performance than legacy CNI

### DNS Settings

- **DNS Enabled**: `true` (automatic container name resolution)
- **External DNS**: Google DNS (8.8.8.8, 8.8.4.4) for internet access
- **Network**: Default `podman` network (automatically created)

## Port Exposure Rules

### Internal Communication (No -p needed)

```bash
# Service A
podman run -d --name service-a my-service

# Service B can access A directly
podman run --rm alpine wget http://service-a:8080
```

### External Access (Use -p)

```bash
# Expose to host for external access
podman run -d --name api -p 8080:8080 my-api

# Now accessible from host
curl http://localhost:8080
```

## Verification

### Check Configuration

```bash
# Verify containers.conf
cat ~/.config/containers/containers.conf

# Check network backend
podman info | grep -i network

# Verify DNS is enabled
podman network inspect podman | jq '.[0].dns_enabled'
```

### Test DNS Resolution

```bash
# Start a test container
podman run -d --name test nginx

# Test DNS from another container
podman run --rm alpine sh -c "
    ping -c 2 test
    nslookup test
"

# Cleanup
podman rm -f test
```

## Troubleshooting

### DNS Not Working

1. **Check network backend**:
   ```bash
   podman info | grep networkBackend
   ```
   Should show `netavark`. If it shows `cni`, update Podman or install netavark.

2. **Verify DNS enabled**:
   ```bash
   podman network inspect podman | jq '.[0].dns_enabled'
   ```
   Should return `true`.

3. **Recreate default network**:
   ```bash
   podman network rm podman
   podman network create podman
   ```

### Container Name Not Resolving

1. **Check container is running**:
   ```bash
   podman ps
   ```

2. **Verify both containers on same network**:
   ```bash
   podman inspect <container> | jq '.[0].NetworkSettings.Networks'
   ```

3. **Test with ping**:
   ```bash
   podman run --rm alpine ping -c 2 <container-name>
   ```

### Network Backend Issues

If using older Podman with CNI backend:

```bash
# Install netavark (Fedora/RHEL)
sudo dnf install netavark aardvark-dns

# Or upgrade Podman
sudo dnf upgrade podman
```

## Advanced Usage

### Explicitly Use Default Network

```bash
# These are equivalent (default network is used automatically)
podman run --name app myimage
podman run --network podman --name app myimage
```

### Multiple Networks

```bash
# Create additional network
podman network create app-net

# Connect to both networks
podman run --name app \
    --network podman \
    --network app-net \
    myimage
```

### Check Container Network

```bash
# See which network a container is using
podman inspect mycontainer | jq '.[0].NetworkSettings.Networks'
```

## Common Patterns

### Pattern 1: Development Stack

```bash
# Database
podman run -d --name postgres \
    -e POSTGRES_PASSWORD=dev \
    postgres

# Cache
podman run -d --name redis redis

# Application
podman run -d --name app -p 3000:3000 \
    -e DB_HOST=postgres \
    -e REDIS_HOST=redis \
    my-app

# App connects to postgres:5432 and redis:6379 internally
```

### Pattern 2: Microservices

```bash
# Auth service
podman run -d --name auth auth-service

# API gateway
podman run -d --name api api-gateway

# Frontend (only this exposed)
podman run -d --name web -p 80:80 \
    -e AUTH_URL=http://auth:8080 \
    -e API_URL=http://api:8080 \
    frontend
```

### Pattern 3: Testing

```bash
# Service under test
podman run -d --name service my-service

# Run tests
podman run --rm test-runner \
    pytest --host=service --port=8080

# Cleanup
podman rm -f service
```

## Benefits

✅ **No Custom Networks**: Uses Podman's default network  
✅ **DNS Resolution**: Containers communicate by name  
✅ **Zero Configuration**: Works automatically after setup  
✅ **No Port Conflicts**: Internal communication doesn't need host ports  
✅ **Simple**: Just use `--name` when running containers  

## Configuration File Location

- **User (rootless)**: `~/.config/containers/containers.conf`
- **System (root)**: `/etc/containers/containers.conf`

## Comparison: Before vs After

### Before (Without DNS)

```bash
# Need to find IP addresses
podman inspect db | jq '.[0].NetworkSettings.IPAddress'
# Use IP in connection string
podman run --rm app --db-host=10.88.0.2
```

### After (With DNS)

```bash
# Just use the container name
podman run -d --name db postgres
podman run --rm app --db-host=db
```

## Additional Resources

- [Podman Network Documentation](https://docs.podman.io/en/latest/markdown/podman-network.1.html)
- [Netavark Documentation](https://github.com/containers/netavark)
- [containers.conf Documentation](https://github.com/containers/common/blob/main/docs/containers.conf.5.md)