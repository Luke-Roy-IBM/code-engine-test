# How to Make Podman Load Your New Configuration

## Important: Podman Reads Config Automatically

**Good news**: Podman automatically reads `/etc/containers/containers.conf` on **every command**. You don't need to restart anything!

## Why Your Settings Might Not Be Applied

If you created `/etc/containers/containers.conf` but don't see changes, here are the reasons and solutions:

### 1. Existing Containers Won't Change

**Problem**: Configuration only affects **new** containers, not existing ones.

**Solution**: Remove and recreate containers:

```bash
# Stop and remove existing containers
podman stop $(podman ps -aq)
podman rm $(podman ps -aq)

# Create new containers - they will use new config
podman run -d --name web nginx
```

### 2. Network Already Exists Without DNS

**Problem**: If the `podman` network was created before you added DNS settings, it won't have DNS enabled.

**Solution**: Recreate the network:

```bash
# Remove existing default network
podman network rm podman

# Create it again (will use new config with DNS)
podman network create podman

# Or let Podman create it automatically on next container run
podman run -d --name test nginx
```

### 3. Running as Root vs Rootless

**Problem**: `/etc/containers/containers.conf` is for **root** Podman. If you're running rootless Podman, it uses `~/.config/containers/containers.conf`.

**Check which mode you're using**:

```bash
# Check if running as root
id

# If uid=0, you're root
# If uid=1000 (or other), you're rootless
```

**Solution for Rootless**:

```bash
# Copy config to user directory
mkdir -p ~/.config/containers
sudo cp /etc/containers/containers.conf ~/.config/containers/
sudo chown $USER:$USER ~/.config/containers/containers.conf
```

**Or run Podman as root**:

```bash
# Use sudo to run as root
sudo podman run -d --name web nginx
```

### 4. Configuration Syntax Error

**Problem**: TOML syntax error prevents config from loading.

**Solution**: Validate your config:

```bash
# View the file
cat /etc/containers/containers.conf

# Check for common errors:
# - Missing quotes around strings
# - Missing closing brackets
# - Incorrect indentation
```

## Step-by-Step: Apply Your New Configuration

### For Root Podman

```bash
# 1. Verify config file exists and is readable
sudo cat /etc/containers/containers.conf

# 2. Remove existing containers (they won't use new config)
sudo podman rm -f $(sudo podman ps -aq)

# 3. Remove and recreate the default network
sudo podman network rm podman
sudo podman network create podman

# 4. Verify DNS is enabled
sudo podman network inspect podman | jq '.[0].dns_enabled'

# 5. Test with new containers
sudo podman run -d --name web nginx
sudo podman run --rm alpine nslookup web
```

### For Rootless Podman

```bash
# 1. Copy config to user directory
mkdir -p ~/.config/containers
sudo cp /etc/containers/containers.conf ~/.config/containers/
sudo chown $USER:$USER ~/.config/containers/containers.conf

# 2. Remove existing containers
podman rm -f $(podman ps -aq)

# 3. Remove and recreate the default network
podman network rm podman
podman network create podman

# 4. Verify DNS is enabled
podman network inspect podman | jq '.[0].dns_enabled'

# 5. Test with new containers
podman run -d --name web nginx
podman run --rm alpine nslookup web
```

## Quick Verification Script

Save this as `verify-config.sh`:

```bash
#!/bin/bash

echo "=== Podman Configuration Verification ==="
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo "Running as: ROOT"
    CONFIG_FILE="/etc/containers/containers.conf"
    PODMAN="podman"
else
    echo "Running as: ROOTLESS (user: $USER)"
    CONFIG_FILE="$HOME/.config/containers/containers.conf"
    PODMAN="podman"
fi

echo "Config file: $CONFIG_FILE"
echo ""

# Check if config exists
if [ -f "$CONFIG_FILE" ]; then
    echo "✓ Config file exists"
    echo ""
    echo "Config content:"
    cat "$CONFIG_FILE"
else
    echo "✗ Config file NOT found"
    exit 1
fi

echo ""
echo "=== Network Backend ==="
$PODMAN info | grep networkBackend

echo ""
echo "=== Default Network DNS ==="
if $PODMAN network exists podman 2>/dev/null; then
    $PODMAN network inspect podman | jq '.[0].dns_enabled'
else
    echo "Default 'podman' network doesn't exist yet"
    echo "It will be created automatically on first container run"
fi

echo ""
echo "=== Test DNS Resolution ==="
echo "Starting test container..."
$PODMAN run -d --name dns-test nginx 2>/dev/null || echo "Container already exists"

echo "Testing DNS from another container..."
if $PODMAN run --rm alpine nslookup dns-test 2>/dev/null; then
    echo "✓ DNS resolution working!"
else
    echo "✗ DNS resolution failed"
fi

echo ""
echo "Cleaning up test container..."
$PODMAN rm -f dns-test >/dev/null 2>&1

echo ""
echo "=== Verification Complete ==="
```

Run it:

```bash
chmod +x verify-config.sh
./verify-config.sh
```

## Common Issues and Solutions

### Issue 1: "Config file exists but settings not applied"

**Cause**: Existing network created before config change.

**Fix**:
```bash
podman network rm podman
podman network create podman
```

### Issue 2: "DNS still not working"

**Cause**: Network backend is CNI instead of netavark.

**Fix**:
```bash
# Check backend
podman info | grep networkBackend

# If it shows 'cni', install netavark
sudo dnf install netavark aardvark-dns

# Or upgrade Podman
sudo dnf upgrade podman
```

### Issue 3: "Permission denied reading config"

**Cause**: Config file not readable.

**Fix**:
```bash
sudo chmod 644 /etc/containers/containers.conf
```

### Issue 4: "Changes work for root but not for my user"

**Cause**: Rootless Podman uses different config location.

**Fix**:
```bash
mkdir -p ~/.config/containers
cp /etc/containers/containers.conf ~/.config/containers/
```

## Testing Your Configuration

### Test 1: Network Backend

```bash
# Should show 'netavark'
podman info | grep networkBackend
```

### Test 2: DNS Enabled

```bash
# Should return 'true'
podman network inspect podman | jq '.[0].dns_enabled'
```

### Test 3: Container Communication

```bash
# Start server
podman run -d --name server nginx

# Test from client
podman run --rm alpine wget -qO- http://server

# Should show nginx welcome page
```

### Test 4: Name Resolution

```bash
# Start container
podman run -d --name test nginx

# Check DNS
podman run --rm alpine nslookup test

# Should resolve to container IP
```

## What Happens When You Run Podman

1. **Podman starts**
2. **Reads config files** in order:
   - `/usr/share/containers/containers.conf` (defaults)
   - `/etc/containers/containers.conf` (your file)
   - `~/.config/containers/containers.conf` (user override)
3. **Merges settings** (later files override earlier ones)
4. **Applies configuration** to the command
5. **Executes command** with merged config

**No restart needed** - config is read every time!

## Summary

✅ **Podman reads config automatically** - no restart needed  
✅ **New containers** use new config immediately  
✅ **Existing containers** need to be recreated  
✅ **Networks** may need to be recreated  
✅ **Root vs Rootless** use different config locations  

## Quick Fix Commands

```bash
# For root Podman
sudo podman network rm podman
sudo podman network create podman
sudo podman run -d --name test nginx
sudo podman run --rm alpine nslookup test

# For rootless Podman
mkdir -p ~/.config/containers
sudo cp /etc/containers/containers.conf ~/.config/containers/
sudo chown $USER:$USER ~/.config/containers/containers.conf
podman network rm podman
podman network create podman
podman run -d --name test nginx
podman run --rm alpine nslookup test
```

If DNS works in the last command, your configuration is active! 🎉