# Why containers.conf Doesn't Show in `podman info`

## The Issue

When you run `podman info`, you might notice that your `containers.conf` file location or settings aren't explicitly shown in the output. This is expected behavior.

## Why This Happens

### 1. **Configuration is Applied, Not Displayed**

`podman info` shows the **current state** of Podman, not the configuration files. The settings from `containers.conf` are already applied to Podman's runtime, so you see the **results** of the configuration, not the file itself.

### 2. **Multiple Configuration Sources**

Podman reads configuration from multiple locations in order:
1. `/usr/share/containers/containers.conf` (system defaults)
2. `/etc/containers/containers.conf` (system-wide overrides)
3. `~/.config/containers/containers.conf` (user-specific overrides)

`podman info` doesn't show which file was used because it merges all of them.

### 3. **Settings Are Reflected in Output**

Instead of showing the config file, `podman info` shows the **effective settings**. For example:

```bash
# Your containers.conf has:
[network]
network_backend = "netavark"
dns_enabled = true

# podman info shows the result:
$ podman info | grep -i network
  networkBackend: netavark
  networkBackendInfo:
```

## How to Verify Your Configuration

### Method 1: Check Effective Settings

```bash
# Check network backend (should be netavark)
podman info | grep networkBackend

# Check network configuration
podman info --format json | jq '.host.networkBackend'
```

### Method 2: Verify File Exists and Is Read

```bash
# Check if file exists
ls -la ~/.config/containers/containers.conf

# View the file content
cat ~/.config/containers/containers.conf

# Check file permissions (should be readable)
stat ~/.config/containers/containers.conf
```

### Method 3: Test DNS Functionality

The best way to verify your configuration works is to test it:

```bash
# Start a container
podman run -d --name test nginx

# Try to resolve it from another container
podman run --rm alpine nslookup test

# If DNS works, your configuration is active
```

### Method 4: Check Network DNS Setting

```bash
# Verify DNS is enabled on the network
podman network inspect podman | jq '.[0].dns_enabled'

# Should return: true
```

### Method 5: Use Debug Mode

```bash
# Run with debug logging to see config file loading
podman --log-level=debug info 2>&1 | grep containers.conf

# This will show which config files are being read
```

## What `podman info` Actually Shows

### Network-Related Information

```bash
$ podman info | grep -A 10 network
host:
  networkBackend: netavark
  networkBackendInfo:
    backend: netavark
    dns:
      enable: true
      package: aardvark-dns
    version: 1.x.x
```

This tells you:
- ✅ Network backend is netavark (from your config)
- ✅ DNS is enabled (from your config)
- ✅ Configuration is working

### Storage Information

```bash
$ podman info | grep -A 5 graphRoot
  graphRoot: /home/user/.local/share/containers/storage
  graphDriverName: overlay
```

This shows storage settings (which can also be in containers.conf).

## Common Misconceptions

### ❌ "Config file path should be in podman info"

**Reality**: Podman doesn't show config file paths in `podman info`. It shows the effective configuration.

### ❌ "If I don't see containers.conf, it's not being used"

**Reality**: If the settings from your `containers.conf` are reflected in `podman info` output (like `networkBackend: netavark`), then it IS being used.

### ❌ "I need to restart Podman after changing containers.conf"

**Reality**: Podman reads `containers.conf` each time you run a command. No restart needed. However, existing containers won't be affected - only new ones.

## Verification Checklist

Use this checklist to confirm your configuration is working:

- [ ] File exists at `~/.config/containers/containers.conf`
- [ ] File is readable: `cat ~/.config/containers/containers.conf`
- [ ] Network backend is netavark: `podman info | grep networkBackend`
- [ ] DNS is enabled on network: `podman network inspect podman | jq '.[0].dns_enabled'`
- [ ] DNS resolution works: Test with two containers

## Example: Full Verification

```bash
# 1. Check file exists
$ ls -la ~/.config/containers/containers.conf
-rw-r--r-- 1 user user 423 Apr 9 12:00 /home/user/.config/containers/containers.conf

# 2. View configuration
$ cat ~/.config/containers/containers.conf
[network]
network_backend = "netavark"
dns_enabled = true
...

# 3. Check effective settings
$ podman info | grep networkBackend
  networkBackend: netavark

# 4. Test DNS
$ podman run -d --name web nginx
$ podman run --rm alpine nslookup web
Server:    10.88.0.1
Address:   10.88.0.1:53

Name:      web
Address:   10.88.0.2

# ✅ Configuration is working!
```

## When Configuration Isn't Applied

If your settings don't seem to be working:

### 1. Check File Location

```bash
# Rootless Podman (most common)
~/.config/containers/containers.conf

# Root Podman
/etc/containers/containers.conf
```

### 2. Check File Syntax

```bash
# Validate TOML syntax
cat ~/.config/containers/containers.conf

# Look for syntax errors (missing quotes, brackets, etc.)
```

### 3. Check Permissions

```bash
# File should be readable
chmod 644 ~/.config/containers/containers.conf

# Directory should be accessible
chmod 755 ~/.config/containers
```

### 4. Check for Overrides

```bash
# System config might override user config
cat /etc/containers/containers.conf

# Check if there are conflicting settings
```

### 5. Use Explicit Config

```bash
# Force Podman to use specific config file
podman --config ~/.config/containers/containers.conf info
```

## Alternative: Check Configuration Directly

Instead of relying on `podman info`, you can check configuration directly:

```bash
# Show all configuration sources
podman system connection list

# Show effective configuration (if available in your Podman version)
podman system info --format json | jq '.host'

# Check specific settings
podman network ls
podman network inspect podman
```

## Summary

**Why you don't see containers.conf in `podman info`:**
- `podman info` shows **effective state**, not configuration files
- Configuration is **applied** but not **displayed**
- Settings from containers.conf are **merged** into the output

**How to verify it's working:**
- Check `networkBackend` in `podman info`
- Test DNS resolution between containers
- Inspect network with `podman network inspect podman`

**The configuration IS working if:**
- ✅ `podman info | grep networkBackend` shows `netavark`
- ✅ `podman network inspect podman | jq '.[0].dns_enabled'` returns `true`
- ✅ Containers can resolve each other by name

You don't need to see the config file path in `podman info` - you just need to verify the settings are applied!